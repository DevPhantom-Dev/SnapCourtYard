"Edge-to-edge courtyard snapping for selected footprints."

import pcbnew


AXIS_X = "x"
AXIS_Y = "y"


def _vec(x, y):
    "Return VECTOR2I (KiCad 7+) or wxPoint (KiCad 6)."
    try:
        return pcbnew.VECTOR2I(int(x), int(y))
    except (TypeError, AttributeError):
        return pcbnew.wxPoint(int(x), int(y))


def _courtyard_polyset(footprint):
    "Return merged front+back courtyard SHAPE_POLY_SET, or None."
    layers = []
    for layer_name in ("F_CrtYd", "B_CrtYd"):
        layer_id = getattr(pcbnew, layer_name, None)
        if layer_id is None:
            continue
        try:
            poly = footprint.GetCourtyard(layer_id)
        except Exception:
            poly = None
        if poly and poly.OutlineCount() > 0:
            layers.append(poly)

    if not layers:
        return None

    merged = pcbnew.SHAPE_POLY_SET()
    for poly in layers:
        merged.Append(poly)
    return merged


def courtyard_bbox(footprint):
    "Return BOX2I of courtyard; fall back to footprint bbox if none."
    poly = _courtyard_polyset(footprint)
    if poly is None or poly.OutlineCount() == 0:
        return footprint.GetBoundingBox(False, False)
    return poly.BBox()


def snap_edge_to_edge(footprints, axis=AXIS_X, gap_nm=0):
    "Chain footprints so courtyards abut. Returns count moved."
    if len(footprints) < 2:
        return 0

    def pos_key(fp):
        p = fp.GetPosition()
        return p.x if axis == AXIS_X else p.y

    ordered = sorted(footprints, key=pos_key)
    moved = 0

    prev_bbox = courtyard_bbox(ordered[0])
    for fp in ordered[1:]:
        cur_bbox = courtyard_bbox(fp)
        if axis == AXIS_X:
            delta = (prev_bbox.GetRight() + gap_nm) - cur_bbox.GetLeft()
            offset = _vec(delta, 0)
        else:
            delta = (prev_bbox.GetBottom() + gap_nm) - cur_bbox.GetTop()
            offset = _vec(0, delta)

        fp.Move(offset)
        moved += 1
        prev_bbox = courtyard_bbox(fp)

    return moved


def selected_footprints(board):
    return [fp for fp in board.GetFootprints() if fp.IsSelected() and not fp.IsLocked()]
