"SnapCourtYard ActionPlugin entry point."

import os

import pcbnew
import wx

from .snap_logic import (
    CORNERS,
    CORNER_LABELS,
    selected_footprints,
    snap_corner_to_corner,
)


class _CornerGrid(wx.Panel):
    "2x2 radio grid for picking a bbox corner."

    def __init__(self, parent, label, default="BR"):
        super().__init__(parent)
        outer = wx.StaticBoxSizer(wx.StaticBox(self, label=label), wx.VERTICAL)
        grid = wx.GridSizer(rows=2, cols=2, hgap=4, vgap=4)

        self._buttons = {}
        first = True
        for corner in ("TL", "TR", "BL", "BR"):
            style = wx.RB_GROUP if first else 0
            rb = wx.RadioButton(self, label=CORNER_LABELS[corner], style=style)
            if corner == default:
                rb.SetValue(True)
            grid.Add(rb, flag=wx.EXPAND)
            self._buttons[corner] = rb
            first = False

        outer.Add(grid, proportion=1, flag=wx.EXPAND | wx.ALL, border=4)
        self.SetSizer(outer)

    def value(self):
        for corner, rb in self._buttons.items():
            if rb.GetValue():
                return corner
        return "TL"


class _SnapDialog(wx.Dialog):
    def __init__(self, parent, footprints):
        super().__init__(parent, title="Snap CourtYard - Corner to Corner",
                         size=(460, 360))
        self._footprints = footprints

        root = wx.BoxSizer(wx.VERTICAL)

        anchor_row = wx.BoxSizer(wx.HORIZONTAL)
        anchor_row.Add(wx.StaticText(self, label="Anchor footprint:"),
                       flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=8)
        refs = [self._label(fp) for fp in footprints]
        self.anchor_choice = wx.Choice(self, choices=refs)
        self.anchor_choice.SetSelection(0)
        anchor_row.Add(self.anchor_choice, proportion=1)
        root.Add(anchor_row, flag=wx.ALL | wx.EXPAND, border=10)

        grids = wx.BoxSizer(wx.HORIZONTAL)
        self.anchor_grid = _CornerGrid(self, "Anchor corner", default="BR")
        self.move_grid = _CornerGrid(self, "Moving corner", default="TL")
        grids.Add(self.anchor_grid, proportion=1, flag=wx.EXPAND | wx.RIGHT, border=8)
        grids.Add(self.move_grid, proportion=1, flag=wx.EXPAND)
        root.Add(grids, proportion=1, flag=wx.ALL | wx.EXPAND, border=10)

        off_box = wx.StaticBoxSizer(wx.StaticBox(self, label="Offset (mm)"),
                                    wx.HORIZONTAL)
        off_box.Add(wx.StaticText(self, label="dx:"),
                    flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=4)
        self.dx_ctrl = wx.TextCtrl(self, value="0")
        off_box.Add(self.dx_ctrl, proportion=1, flag=wx.RIGHT, border=12)
        off_box.Add(wx.StaticText(self, label="dy:"),
                    flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=4)
        self.dy_ctrl = wx.TextCtrl(self, value="0")
        off_box.Add(self.dy_ctrl, proportion=1)
        root.Add(off_box, flag=wx.ALL | wx.EXPAND, border=10)

        root.Add(self.CreateButtonSizer(wx.OK | wx.CANCEL),
                 flag=wx.ALL | wx.EXPAND, border=8)
        self.SetSizer(root)

    @staticmethod
    def _label(fp):
        ref = fp.GetReference() or "?"
        val = fp.GetValue() or ""
        return "{} ({})".format(ref, val) if val else ref

    def anchor_index(self):
        idx = self.anchor_choice.GetSelection()
        return idx if idx != wx.NOT_FOUND else 0

    def anchor_corner(self):
        return self.anchor_grid.value()

    def move_corner(self):
        return self.move_grid.value()

    def offset_nm(self):
        def parse(ctrl):
            try:
                return pcbnew.FromMM(float(ctrl.GetValue().replace(",", ".")))
            except ValueError:
                return 0
        return parse(self.dx_ctrl), parse(self.dy_ctrl)


class SnapCourtYardPlugin(pcbnew.ActionPlugin):
    "main class of action plugin"

    def defaults(self):
        self.name = "Snap CourtYard"
        self.category = "Layout Helper"
        self.description = "Snap selected footprint courtyard corner to another corner."
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "icon.png")

    def Run(self):
        board = pcbnew.GetBoard()
        if board is None:
            wx.MessageBox("No board open.", "Snap CourtYard", wx.ICON_ERROR)
            return

        fps = selected_footprints(board)
        if len(fps) != 2:
            wx.MessageBox(
                "Select exactly two unlocked footprints (got {}).".format(len(fps)),
                "Snap CourtYard", wx.ICON_INFORMATION)
            return

        dlg = _SnapDialog(None, fps)
        try:
            if dlg.ShowModal() != wx.ID_OK:
                return
            a_idx = dlg.anchor_index()
            a_corner = dlg.anchor_corner()
            m_corner = dlg.move_corner()
            dx, dy = dlg.offset_nm()
        finally:
            dlg.Destroy()

        anchor = fps[a_idx]
        moving = fps[1 - a_idx]

        snap_corner_to_corner(anchor, moving, a_corner, m_corner,
                              dx_nm=dx, dy_nm=dy)
        pcbnew.Refresh()
