"Corner-to-corner courtyard snapping."

import pcbnew


CORNERS = ("TL", "TR", "BL", "BR")
CORNER_LABELS = {
    "TL": "Top-Left",
    "TR": "Top-Right",
    "BL": "Bottom-Left",
    "BR": "Bottom-Right",
}


def _vec(x, y):
    "Return VECTOR2I (KiCad 7+) or wxPoint (KiCad 6)."
    try:
        return pcbnew.VECTOR2I(int(x), int(y))
    except (TypeError, AttributeError):
        return pcbnew.wxPoint(int(x), int(y))


def _courtyard_polyset(footprint):
    "Return merged front+back courtyard SHAPE_POLY_SET, or None."
    layers = []
    for layer_name in ("F_CrtYd", "B_CrtYd"):
        layer_id = getattr(pcbnew, layer_name, None)
        if layer_id is None:
            continue
        try:
            poly = footprint.GetCourtyard(layer_id)
        except Exception:
            poly = None
        if poly and poly.OutlineCount() > 0:
            layers.append(poly)

    if not layers:
        return None

    merged = pcbnew.SHAPE_POLY_SET()
    for poly in layers:
        merged.Append(poly)
    return merged


def courtyard_bbox(footprint):
    "Return BOX2I of courtyard; fall back to footprint bbox if none."
    poly = _courtyard_polyset(footprint)
    if poly is None or poly.OutlineCount() == 0:
        return footprint.GetBoundingBox(False, False)
    return poly.BBox()


def corner_point(bbox, corner):
    "Return (x, y) in board units (nm). KiCad y grows downward."
    if corner not in CORNERS:
        raise ValueError("bad corner: {}".format(corner))
    x = bbox.GetLeft() if corner in ("TL", "BL") else bbox.GetRight()
    y = bbox.GetTop() if corner in ("TL", "TR") else bbox.GetBottom()
    return x, y


def snap_corner_to_corner(anchor_fp, move_fp, anchor_corner, move_corner,
                          dx_nm=0, dy_nm=0):
    "Move move_fp so its corner lands on anchor_fp corner (plus optional offset)."
    a_bbox = courtyard_bbox(anchor_fp)
    m_bbox = courtyard_bbox(move_fp)
    ax, ay = corner_point(a_bbox, anchor_corner)
    mx, my = corner_point(m_bbox, move_corner)
    move_fp.Move(_vec(ax - mx + dx_nm, ay - my + dy_nm))


def selected_footprints(board):
    return [fp for fp in board.GetFootprints() if fp.IsSelected() and not fp.IsLocked()]
