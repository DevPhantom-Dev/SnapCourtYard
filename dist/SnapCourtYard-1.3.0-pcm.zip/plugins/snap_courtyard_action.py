"SnapCourtYard ActionPlugin entry point."

import json
import os

import pcbnew
import wx


SETTINGS_PATH = os.path.join(os.path.expanduser("~"), ".snapcourtyard.json")


def _load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return {}


def _save_settings(data):
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass

from .snap_logic import (
    CORNER_LABELS,
    EDGE_LABELS,
    HORIZONTAL_EDGES,
    selected_footprints,
    snap_corner_to_corner,
    snap_edge_to_edge,
)


class _CornerGrid(wx.Panel):
    "2x2 radio grid for picking a bbox corner."

    def __init__(self, parent, label, default="BR"):
        super().__init__(parent)
        outer = wx.StaticBoxSizer(wx.StaticBox(self, label=label), wx.VERTICAL)
        grid = wx.GridSizer(rows=2, cols=2, hgap=4, vgap=4)

        self._buttons = {}
        first = True
        for corner in ("TL", "TR", "BL", "BR"):
            style = wx.RB_GROUP if first else 0
            rb = wx.RadioButton(self, label=CORNER_LABELS[corner], style=style)
            if corner == default:
                rb.SetValue(True)
            grid.Add(rb, flag=wx.EXPAND)
            self._buttons[corner] = rb
            first = False

        outer.Add(grid, proportion=1, flag=wx.EXPAND | wx.ALL, border=4)
        self.SetSizer(outer)

    def value(self):
        for corner, rb in self._buttons.items():
            if rb.GetValue():
                return corner
        return "TL"


class _EdgeGrid(wx.Panel):
    "Cross-shaped radio grid for picking a bbox edge."

    def __init__(self, parent, label, default="R"):
        super().__init__(parent)
        outer = wx.StaticBoxSizer(wx.StaticBox(self, label=label), wx.VERTICAL)
        grid = wx.GridSizer(rows=3, cols=3, hgap=4, vgap=4)

        self._buttons = {}
        placement = [
            None, "T", None,
            "L", None, "R",
            None, "B", None,
        ]
        first = True
        for cell in placement:
            if cell is None:
                grid.Add(wx.StaticText(self, label=""), flag=wx.EXPAND)
                continue
            style = wx.RB_GROUP if first else 0
            rb = wx.RadioButton(self, label=EDGE_LABELS[cell], style=style)
            if cell == default:
                rb.SetValue(True)
            grid.Add(rb, flag=wx.ALIGN_CENTER)
            self._buttons[cell] = rb
            first = False

        outer.Add(grid, proportion=1, flag=wx.EXPAND | wx.ALL, border=4)
        self.SetSizer(outer)

    def value(self):
        for edge, rb in self._buttons.items():
            if rb.GetValue():
                return edge
        return "R"


class _CornerPage(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)
        sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.anchor = _CornerGrid(self, "Anchor corner", default="BR")
        self.move = _CornerGrid(self, "Moving corner", default="TL")
        sizer.Add(self.anchor, proportion=1, flag=wx.EXPAND | wx.ALL, border=6)
        sizer.Add(self.move, proportion=1, flag=wx.EXPAND | wx.ALL, border=6)
        self.SetSizer(sizer)


class _EdgePage(wx.Panel):
    def __init__(self, parent):
        super().__init__(parent)
        sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.anchor = _EdgeGrid(self, "Anchor edge", default="R")
        self.move = _EdgeGrid(self, "Moving edge", default="L")
        sizer.Add(self.anchor, proportion=1, flag=wx.EXPAND | wx.ALL, border=6)
        sizer.Add(self.move, proportion=1, flag=wx.EXPAND | wx.ALL, border=6)
        self.SetSizer(sizer)


class _SnapDialog(wx.Dialog):
    def __init__(self, parent, footprints, settings):
        super().__init__(parent, title="Snap CourtYard",
                         size=(520, 440))
        self._footprints = footprints
        self._settings = settings

        root = wx.BoxSizer(wx.VERTICAL)

        anchor_row = wx.BoxSizer(wx.HORIZONTAL)
        anchor_row.Add(wx.StaticText(self, label="Anchor footprint:"),
                       flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=8)
        refs = [self._label(fp) for fp in footprints]
        self.anchor_choice = wx.Choice(self, choices=refs)
        self.anchor_choice.SetSelection(0)
        anchor_row.Add(self.anchor_choice, proportion=1)
        root.Add(anchor_row, flag=wx.ALL | wx.EXPAND, border=10)

        self.notebook = wx.Notebook(self)
        self.corner_page = _CornerPage(self.notebook)
        self.edge_page = _EdgePage(self.notebook)
        self.notebook.AddPage(self.corner_page, "Corner to Corner")
        self.notebook.AddPage(self.edge_page, "Edge to Edge")
        root.Add(self.notebook, proportion=1, flag=wx.ALL | wx.EXPAND, border=10)

        off_box = wx.StaticBoxSizer(wx.StaticBox(self, label="Offset (mm)"),
                                    wx.HORIZONTAL)
        dx_default = str(settings.get("dx_mm", 0))
        dy_default = str(settings.get("dy_mm", 0))
        off_box.Add(wx.StaticText(self, label="dx:"),
                    flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=4)
        self.dx_ctrl = wx.TextCtrl(self, value=dx_default)
        off_box.Add(self.dx_ctrl, proportion=1, flag=wx.RIGHT, border=12)
        off_box.Add(wx.StaticText(self, label="dy:"),
                    flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=4)
        self.dy_ctrl = wx.TextCtrl(self, value=dy_default)
        off_box.Add(self.dy_ctrl, proportion=1)
        root.Add(off_box, flag=wx.ALL | wx.EXPAND, border=10)

        root.Add(self.CreateButtonSizer(wx.OK | wx.CANCEL),
                 flag=wx.ALL | wx.EXPAND, border=8)
        self.SetSizer(root)

    @staticmethod
    def _label(fp):
        ref = fp.GetReference() or "?"
        val = fp.GetValue() or ""
        return "{} ({})".format(ref, val) if val else ref

    def anchor_index(self):
        idx = self.anchor_choice.GetSelection()
        return idx if idx != wx.NOT_FOUND else 0

    def mode(self):
        return "edge" if self.notebook.GetSelection() == 1 else "corner"

    def corner_selection(self):
        return self.corner_page.anchor.value(), self.corner_page.move.value()

    def edge_selection(self):
        return self.edge_page.anchor.value(), self.edge_page.move.value()

    def offset_mm(self):
        def parse(ctrl):
            try:
                return float(ctrl.GetValue().replace(",", "."))
            except ValueError:
                return 0.0
        return parse(self.dx_ctrl), parse(self.dy_ctrl)

    def offset_nm(self):
        dx_mm, dy_mm = self.offset_mm()
        return pcbnew.FromMM(dx_mm), pcbnew.FromMM(dy_mm)


class SnapCourtYardPlugin(pcbnew.ActionPlugin):
    "main class of action plugin"

    def defaults(self):
        self.name = "Snap CourtYard"
        self.category = "Layout Helper"
        self.description = "Snap footprint courtyards corner-to-corner or edge-to-edge."
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "icon.png")

    def Run(self):
        board = pcbnew.GetBoard()
        if board is None:
            wx.MessageBox("No board open.", "Snap CourtYard", wx.ICON_ERROR)
            return

        fps = selected_footprints(board)
        if len(fps) != 2:
            wx.MessageBox(
                "Select exactly two unlocked footprints (got {}).".format(len(fps)),
                "Snap CourtYard", wx.ICON_INFORMATION)
            return

        settings = _load_settings()
        dlg = _SnapDialog(None, fps, settings)
        try:
            if dlg.ShowModal() != wx.ID_OK:
                return
            a_idx = dlg.anchor_index()
            mode = dlg.mode()
            dx_mm, dy_mm = dlg.offset_mm()
            dx, dy = dlg.offset_nm()
            if mode == "corner":
                a_corner, m_corner = dlg.corner_selection()
            else:
                a_edge, m_edge = dlg.edge_selection()
        finally:
            dlg.Destroy()

        settings["dx_mm"] = dx_mm
        settings["dy_mm"] = dy_mm
        _save_settings(settings)

        anchor = fps[a_idx]
        moving = fps[1 - a_idx]

        if mode == "corner":
            snap_corner_to_corner(anchor, moving, a_corner, m_corner,
                                  dx_nm=dx, dy_nm=dy)
        else:
            a_horiz = a_edge in HORIZONTAL_EDGES
            m_horiz = m_edge in HORIZONTAL_EDGES
            if a_horiz != m_horiz:
                wx.MessageBox(
                    "Anchor and moving edges must share orientation "
                    "(both Top/Bottom or both Left/Right).",
                    "Snap CourtYard", wx.ICON_ERROR)
                return
            snap_edge_to_edge(anchor, moving, a_edge, m_edge,
                              dx_nm=dx, dy_nm=dy)

        pcbnew.Refresh()
