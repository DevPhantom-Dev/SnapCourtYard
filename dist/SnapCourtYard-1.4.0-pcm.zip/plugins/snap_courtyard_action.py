"SnapCourtYard ActionPlugin entry point."

import json
import os

import pcbnew
import wx

from .snap_logic import (
    HORIZONTAL_EDGES,
    selected_footprints,
    snap_corner_to_corner,
    snap_edge_to_edge,
)


SETTINGS_PATH = os.path.join(os.path.expanduser("~"), ".snapcourtyard.json")

CORNER_SLOTS = ("TL", "TR", "BL", "BR")
EDGE_SLOTS = ("T", "R", "B", "L")
ALL_SLOTS = CORNER_SLOTS + EDGE_SLOTS

SLOT_GLYPH = {
    "TL": "┌", "TR": "┐",
    "BL": "└", "BR": "┘",
    "T":  "─", "B":  "─",
    "L":  "│", "R":  "│",
}


def _is_corner(slot):
    return slot in CORNER_SLOTS


def _is_edge(slot):
    return slot in EDGE_SLOTS


def _load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return {}


def _save_settings(data):
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


class _SidePicker(wx.Panel):
    """3x3 grid of toggle buttons forming a rectangle outline.

    Corner cells (TL/TR/BL/BR) and edge cells (T/R/B/L) are clickable;
    center cell is blank. Single-select; click any cell to choose.
    """

    LAYOUT = [
        "TL", "T", "TR",
        "L",  None, "R",
        "BL", "B", "BR",
    ]

    def __init__(self, parent, label, default="BR"):
        super().__init__(parent)
        outer = wx.StaticBoxSizer(wx.StaticBox(self, label=label), wx.VERTICAL)
        grid = wx.GridSizer(rows=3, cols=3, hgap=2, vgap=2)

        self._buttons = {}
        for slot in self.LAYOUT:
            if slot is None:
                grid.Add(wx.StaticText(self, label=""), flag=wx.EXPAND)
                continue
            btn = wx.ToggleButton(self, label=SLOT_GLYPH[slot])
            btn.SetMinSize((42, 32))
            btn.SetToolTip(slot)
            btn.Bind(wx.EVT_TOGGLEBUTTON,
                     lambda e, s=slot: self._select(s, fire=True))
            grid.Add(btn, flag=wx.EXPAND)
            self._buttons[slot] = btn

        outer.Add(grid, proportion=1, flag=wx.EXPAND | wx.ALL, border=6)
        self.SetSizer(outer)

        self._listener = None
        self.set(default)

    def _select(self, slot, fire=False):
        for s, btn in self._buttons.items():
            btn.SetValue(s == slot)
        if fire and self._listener:
            self._listener(slot)

    def set(self, slot):
        if slot not in self._buttons:
            slot = "BR"
        self._select(slot)

    def value(self):
        for slot, btn in self._buttons.items():
            if btn.GetValue():
                return slot
        return "BR"

    def on_change(self, callback):
        self._listener = callback


class _SnapDialog(wx.Dialog):
    def __init__(self, parent, footprints, settings):
        super().__init__(parent, title="Snap CourtYard",
                         size=(540, 460))
        self._footprints = footprints
        self._settings = settings

        root = wx.BoxSizer(wx.VERTICAL)

        anchor_row = wx.BoxSizer(wx.HORIZONTAL)
        anchor_row.Add(wx.StaticText(self, label="Anchor footprint:"),
                       flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=8)
        refs = [self._label(fp) for fp in footprints]
        self.anchor_choice = wx.Choice(self, choices=refs)
        self.anchor_choice.SetSelection(settings.get("anchor_index", 0)
                                        if settings.get("anchor_index", 0) < len(refs)
                                        else 0)
        anchor_row.Add(self.anchor_choice, proportion=1, flag=wx.RIGHT, border=8)
        self.swap_btn = wx.Button(self, label="Swap")
        self.swap_btn.Bind(wx.EVT_BUTTON, self._on_swap)
        anchor_row.Add(self.swap_btn, flag=wx.ALIGN_CENTER_VERTICAL)
        root.Add(anchor_row, flag=wx.ALL | wx.EXPAND, border=10)

        pickers = wx.BoxSizer(wx.HORIZONTAL)
        self.anchor_picker = _SidePicker(
            self, "Anchor side", default=settings.get("anchor_slot", "BR"))
        self.move_picker = _SidePicker(
            self, "Moving side", default=settings.get("move_slot", "TL"))
        self.anchor_picker.on_change(lambda s: self._refresh_mode_label())
        self.move_picker.on_change(lambda s: self._refresh_mode_label())
        pickers.Add(self.anchor_picker, proportion=1,
                    flag=wx.EXPAND | wx.ALL, border=6)
        pickers.Add(self.move_picker, proportion=1,
                    flag=wx.EXPAND | wx.ALL, border=6)
        root.Add(pickers, proportion=1, flag=wx.ALL | wx.EXPAND, border=6)

        self.mode_label = wx.StaticText(self, label="")
        font = self.mode_label.GetFont()
        font.SetWeight(wx.FONTWEIGHT_BOLD)
        self.mode_label.SetFont(font)
        root.Add(self.mode_label, flag=wx.LEFT | wx.RIGHT, border=12)

        off_box = wx.StaticBoxSizer(wx.StaticBox(self, label="Offset (mm)"),
                                    wx.HORIZONTAL)
        dx_default = str(settings.get("dx_mm", 0))
        dy_default = str(settings.get("dy_mm", 0))
        off_box.Add(wx.StaticText(self, label="dx:"),
                    flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=4)
        self.dx_ctrl = wx.TextCtrl(self, value=dx_default)
        off_box.Add(self.dx_ctrl, proportion=1, flag=wx.RIGHT, border=12)
        off_box.Add(wx.StaticText(self, label="dy:"),
                    flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=4)
        self.dy_ctrl = wx.TextCtrl(self, value=dy_default)
        off_box.Add(self.dy_ctrl, proportion=1)
        root.Add(off_box, flag=wx.ALL | wx.EXPAND, border=10)

        hint = wx.StaticText(
            self,
            label="Tip: bind a hotkey in Preferences > Hotkeys > 'Snap CourtYard'.")
        hint.SetForegroundColour(wx.Colour(120, 120, 120))
        root.Add(hint, flag=wx.LEFT | wx.RIGHT | wx.BOTTOM, border=12)

        root.Add(self.CreateButtonSizer(wx.OK | wx.CANCEL),
                 flag=wx.ALL | wx.EXPAND, border=8)
        self.SetSizer(root)
        self._refresh_mode_label()

    @staticmethod
    def _label(fp):
        ref = fp.GetReference() or "?"
        val = fp.GetValue() or ""
        return "{} ({})".format(ref, val) if val else ref

    def _on_swap(self, _evt):
        sel = self.anchor_choice.GetSelection()
        if sel == wx.NOT_FOUND:
            return
        self.anchor_choice.SetSelection(1 - sel)
        a = self.anchor_picker.value()
        m = self.move_picker.value()
        self.anchor_picker.set(m)
        self.move_picker.set(a)
        self._refresh_mode_label()

    def _refresh_mode_label(self):
        a = self.anchor_picker.value()
        m = self.move_picker.value()
        if _is_corner(a) and _is_corner(m):
            txt = "Mode: Corner -> Corner  ({} -> {})".format(a, m)
            color = wx.Colour(40, 120, 40)
        elif _is_edge(a) and _is_edge(m):
            a_h = a in HORIZONTAL_EDGES
            m_h = m in HORIZONTAL_EDGES
            if a_h == m_h:
                txt = "Mode: Edge -> Edge  ({} -> {})".format(a, m)
                color = wx.Colour(40, 120, 40)
            else:
                txt = "Edges must share orientation (both T/B or both L/R)"
                color = wx.Colour(180, 30, 30)
        else:
            txt = "Pick two corners OR two edges (not mixed)"
            color = wx.Colour(180, 30, 30)
        self.mode_label.SetLabel(txt)
        self.mode_label.SetForegroundColour(color)
        self.Layout()

    def anchor_index(self):
        idx = self.anchor_choice.GetSelection()
        return idx if idx != wx.NOT_FOUND else 0

    def picks(self):
        return self.anchor_picker.value(), self.move_picker.value()

    def offset_mm(self):
        def parse(ctrl):
            try:
                return float(ctrl.GetValue().replace(",", "."))
            except ValueError:
                return 0.0
        return parse(self.dx_ctrl), parse(self.dy_ctrl)

    def offset_nm(self):
        dx_mm, dy_mm = self.offset_mm()
        return pcbnew.FromMM(dx_mm), pcbnew.FromMM(dy_mm)


class SnapCourtYardPlugin(pcbnew.ActionPlugin):
    "main class of action plugin"

    def defaults(self):
        self.name = "Snap CourtYard"
        self.category = "Layout Helper"
        self.description = "Snap footprint courtyards corner-to-corner or edge-to-edge."
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "icon.png")

    def Run(self):
        board = pcbnew.GetBoard()
        if board is None:
            wx.MessageBox("No board open.", "Snap CourtYard", wx.ICON_ERROR)
            return

        fps = selected_footprints(board)
        if len(fps) != 2:
            wx.MessageBox(
                "Select exactly two unlocked footprints (got {}).".format(len(fps)),
                "Snap CourtYard", wx.ICON_INFORMATION)
            return

        settings = _load_settings()
        dlg = _SnapDialog(None, fps, settings)
        try:
            if dlg.ShowModal() != wx.ID_OK:
                return
            a_idx = dlg.anchor_index()
            a_slot, m_slot = dlg.picks()
            dx_mm, dy_mm = dlg.offset_mm()
            dx, dy = dlg.offset_nm()
        finally:
            dlg.Destroy()

        # validate
        if _is_corner(a_slot) and _is_corner(m_slot):
            mode = "corner"
        elif _is_edge(a_slot) and _is_edge(m_slot):
            a_h = a_slot in HORIZONTAL_EDGES
            m_h = m_slot in HORIZONTAL_EDGES
            if a_h != m_h:
                wx.MessageBox(
                    "Edges must share orientation (both Top/Bottom or both Left/Right).",
                    "Snap CourtYard", wx.ICON_ERROR)
                return
            mode = "edge"
        else:
            wx.MessageBox("Pick two corners OR two edges, not a mix.",
                          "Snap CourtYard", wx.ICON_ERROR)
            return

        settings["dx_mm"] = dx_mm
        settings["dy_mm"] = dy_mm
        settings["anchor_index"] = a_idx
        settings["anchor_slot"] = a_slot
        settings["move_slot"] = m_slot
        settings["mode"] = mode
        _save_settings(settings)

        anchor = fps[a_idx]
        moving = fps[1 - a_idx]

        if mode == "corner":
            snap_corner_to_corner(anchor, moving, a_slot, m_slot,
                                  dx_nm=dx, dy_nm=dy)
        else:
            snap_edge_to_edge(anchor, moving, a_slot, m_slot,
                              dx_nm=dx, dy_nm=dy)

        pcbnew.Refresh()
