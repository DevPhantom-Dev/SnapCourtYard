"SnapCourtYard ActionPlugin entry point."

import json
import os

import pcbnew
import wx

from .snap_logic import (
    HORIZONTAL_EDGES,
    snap_corner_to_corner,
    snap_edge_to_edge,
)


SETTINGS_PATH = os.path.join(os.path.expanduser("~"), ".snapcourtyard.json")

CORNER_SLOTS = ("TL", "TR", "BL", "BR")
EDGE_SLOTS = ("T", "R", "B", "L")

SLOT_GLYPH = {
    "TL": "┌", "TR": "┐",
    "BL": "└", "BR": "┘",
    "T":  "─", "B":  "─",
    "L":  "│", "R":  "│",
}


def _is_corner(slot):
    return slot in CORNER_SLOTS


def _is_edge(slot):
    return slot in EDGE_SLOTS


def _load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data
    except (OSError, ValueError):
        pass
    return {}


def _save_settings(data):
    try:
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
    except OSError:
        pass


def _selected_footprints_ordered(board):
    """Return selected unlocked footprints, selection order if possible.

    KiCad 7+: pcbnew.GetCurrentSelection() preserves selection order.
    Last item in returned list = most-recently selected.
    Fallback: board iteration order.
    """
    fp_class = getattr(pcbnew, "FOOTPRINT", None)
    try:
        sel = pcbnew.GetCurrentSelection()
        ordered = []
        for it in sel:
            try:
                if fp_class is not None and not isinstance(it, fp_class):
                    continue
                if not it.IsSelected() or it.IsLocked():
                    continue
                ordered.append(it)
            except Exception:
                continue
        if ordered:
            return ordered
    except Exception:
        pass
    return [fp for fp in board.GetFootprints()
            if fp.IsSelected() and not fp.IsLocked()]


def _valid_combo(a_slot, m_slot):
    if _is_corner(a_slot) and _is_corner(m_slot):
        return True
    if _is_edge(a_slot) and _is_edge(m_slot):
        return (a_slot in HORIZONTAL_EDGES) == (m_slot in HORIZONTAL_EDGES)
    return False


def _do_snap(anchor, moving, a_slot, m_slot, dx_nm, dy_nm):
    if _is_corner(a_slot) and _is_corner(m_slot):
        snap_corner_to_corner(anchor, moving, a_slot, m_slot,
                              dx_nm=dx_nm, dy_nm=dy_nm)
    elif _is_edge(a_slot) and _is_edge(m_slot):
        snap_edge_to_edge(anchor, moving, a_slot, m_slot,
                          dx_nm=dx_nm, dy_nm=dy_nm)


def _apply_chain(footprints, anchor_idx, a_slot, m_slot, dx_nm, dy_nm):
    """Snap chain: anchor first, then each subsequent fp snaps to previous.

    Other footprints stay in their original selection order.
    """
    if len(footprints) < 2:
        return
    anchor = footprints[anchor_idx]
    others = [fp for i, fp in enumerate(footprints) if i != anchor_idx]
    chain = [anchor] + others
    for i in range(1, len(chain)):
        _do_snap(chain[i - 1], chain[i], a_slot, m_slot, dx_nm, dy_nm)


def _apply_persisted(board, footprints):
    """Apply last-used config without dialog."""
    if len(footprints) < 2:
        return False
    settings = _load_settings()
    a_slot = settings.get("anchor_slot", "BR")
    m_slot = settings.get("move_slot", "TL")
    if not _valid_combo(a_slot, m_slot):
        return False
    dx = pcbnew.FromMM(float(settings.get("dx_mm", 0)))
    dy = pcbnew.FromMM(float(settings.get("dy_mm", 0)))
    # anchor = second in selection order (index 1)
    anchor_idx = 1 if len(footprints) >= 2 else 0
    _apply_chain(footprints, anchor_idx, a_slot, m_slot, dx, dy)
    pcbnew.Refresh()
    return True


class _SidePicker(wx.Panel):
    """3x3 grid of toggle buttons forming a rectangle outline."""

    LAYOUT = [
        "TL", "T", "TR",
        "L",  None, "R",
        "BL", "B", "BR",
    ]

    def __init__(self, parent, label, default="BR"):
        super().__init__(parent)
        outer = wx.StaticBoxSizer(wx.StaticBox(self, label=label), wx.VERTICAL)
        grid = wx.GridSizer(rows=3, cols=3, hgap=2, vgap=2)

        self._buttons = {}
        for slot in self.LAYOUT:
            if slot is None:
                grid.Add(wx.StaticText(self, label=""), flag=wx.EXPAND)
                continue
            btn = wx.ToggleButton(self, label=SLOT_GLYPH[slot])
            btn.SetMinSize((42, 32))
            btn.SetToolTip(slot)
            btn.Bind(wx.EVT_TOGGLEBUTTON,
                     lambda e, s=slot: self._select(s, fire=True))
            grid.Add(btn, flag=wx.EXPAND)
            self._buttons[slot] = btn

        outer.Add(grid, proportion=1, flag=wx.EXPAND | wx.ALL, border=6)
        self.SetSizer(outer)

        self._listener = None
        self.set(default)

    def _select(self, slot, fire=False):
        for s, btn in self._buttons.items():
            btn.SetValue(s == slot)
        if fire and self._listener:
            self._listener(slot)

    def set(self, slot):
        if slot not in self._buttons:
            slot = "BR"
        self._select(slot)

    def value(self):
        for slot, btn in self._buttons.items():
            if btn.GetValue():
                return slot
        return "BR"

    def on_change(self, callback):
        self._listener = callback


class _SnapDialog(wx.Dialog):
    def __init__(self, parent, footprints, settings):
        super().__init__(parent, title="Snap CourtYard",
                         size=(560, 500))
        self._footprints = footprints
        self._original_positions = [fp.GetPosition() for fp in footprints]
        self._settings = settings

        root = wx.BoxSizer(wx.VERTICAL)

        # Anchor row: dropdown + Swap
        anchor_row = wx.BoxSizer(wx.HORIZONTAL)
        anchor_row.Add(wx.StaticText(self, label="Anchor footprint:"),
                       flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=8)
        refs = [self._label(fp) for fp in footprints]
        self.anchor_choice = wx.Choice(self, choices=refs)
        # default anchor: second in selection order (index 1).
        # Selection list is selection-ordered, so fp[1] = second-clicked.
        default_idx = 1 if len(footprints) >= 2 else 0
        # Selection composition is volatile (user may re-select);
        # do NOT honour persisted anchor_index. Always use selection default.
        self.anchor_choice.SetSelection(default_idx)
        anchor_row.Add(self.anchor_choice, proportion=1, flag=wx.RIGHT, border=8)
        self.swap_btn = wx.Button(self, label="Swap")
        self.swap_btn.Bind(wx.EVT_BUTTON, self._on_swap)
        anchor_row.Add(self.swap_btn, flag=wx.ALIGN_CENTER_VERTICAL)
        root.Add(anchor_row, flag=wx.ALL | wx.EXPAND, border=10)

        # Chain note (for N>2)
        if len(footprints) > 2:
            note = wx.StaticText(
                self,
                label="Chain mode: {} footprints. Anchor stays; others "
                      "snap in selection order.".format(len(footprints)))
            note.SetForegroundColour(wx.Colour(40, 90, 160))
            root.Add(note, flag=wx.LEFT | wx.RIGHT | wx.BOTTOM, border=12)

        # Pickers
        pickers = wx.BoxSizer(wx.HORIZONTAL)
        self.anchor_picker = _SidePicker(
            self, "Anchor side", default=settings.get("anchor_slot", "BR"))
        self.move_picker = _SidePicker(
            self, "Moving side", default=settings.get("move_slot", "TL"))
        pickers.Add(self.anchor_picker, proportion=1,
                    flag=wx.EXPAND | wx.ALL, border=6)
        pickers.Add(self.move_picker, proportion=1,
                    flag=wx.EXPAND | wx.ALL, border=6)
        root.Add(pickers, proportion=1, flag=wx.ALL | wx.EXPAND, border=6)

        # Mode label
        self.mode_label = wx.StaticText(self, label="")
        font = self.mode_label.GetFont()
        font.SetWeight(wx.FONTWEIGHT_BOLD)
        self.mode_label.SetFont(font)
        root.Add(self.mode_label, flag=wx.LEFT | wx.RIGHT, border=12)

        # Offset
        self.off_static = wx.StaticBox(self, label="Offset (mm)")
        off_box = wx.StaticBoxSizer(self.off_static, wx.HORIZONTAL)
        dx_default = str(settings.get("dx_mm", 0))
        dy_default = str(settings.get("dy_mm", 0))
        off_box.Add(wx.StaticText(self, label="dx:"),
                    flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=4)
        self.dx_ctrl = wx.TextCtrl(self, value=dx_default)
        off_box.Add(self.dx_ctrl, proportion=1, flag=wx.RIGHT, border=12)
        off_box.Add(wx.StaticText(self, label="dy:"),
                    flag=wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, border=4)
        self.dy_ctrl = wx.TextCtrl(self, value=dy_default)
        off_box.Add(self.dy_ctrl, proportion=1, flag=wx.RIGHT, border=8)
        self.reset_btn = wx.Button(self, label="Reset", size=(60, -1))
        self.reset_btn.Bind(wx.EVT_BUTTON, self._on_reset_offset)
        off_box.Add(self.reset_btn, flag=wx.ALIGN_CENTER_VERTICAL)
        root.Add(off_box, flag=wx.ALL | wx.EXPAND, border=10)

        # Hint
        hint = wx.StaticText(
            self,
            label="Tip: bind hotkey via Preferences > Hotkeys.  "
                  "Shift+click toolbar = repeat last config.")
        hint.SetForegroundColour(wx.Colour(120, 120, 120))
        root.Add(hint, flag=wx.LEFT | wx.RIGHT | wx.BOTTOM, border=12)

        # OK/Cancel
        root.Add(self.CreateButtonSizer(wx.OK | wx.CANCEL),
                 flag=wx.ALL | wx.EXPAND, border=8)
        self.SetSizer(root)

        # Wire live preview
        self.anchor_picker.on_change(lambda s: self._update())
        self.move_picker.on_change(lambda s: self._update())
        self.dx_ctrl.Bind(wx.EVT_TEXT, lambda e: self._update())
        self.dy_ctrl.Bind(wx.EVT_TEXT, lambda e: self._update())
        self.anchor_choice.Bind(wx.EVT_CHOICE, lambda e: self._update())
        self.Bind(wx.EVT_BUTTON, self._on_ok, id=wx.ID_OK)
        self.Bind(wx.EVT_BUTTON, self._on_cancel, id=wx.ID_CANCEL)
        self.Bind(wx.EVT_CLOSE, self._on_close)

        self._refresh_mode_label()
        self._refresh_offset_warning()
        self._update()

    @staticmethod
    def _label(fp):
        ref = fp.GetReference() or "?"
        val = fp.GetValue() or ""
        return "{} ({})".format(ref, val) if val else ref

    def _restore_positions(self):
        for fp, pos in zip(self._footprints, self._original_positions):
            try:
                fp.SetPosition(pos)
            except Exception:
                pass

    def _update(self):
        self._restore_positions()
        a_slot = self.anchor_picker.value()
        m_slot = self.move_picker.value()
        if _valid_combo(a_slot, m_slot):
            try:
                dx, dy = self.offset_nm()
                _apply_chain(self._footprints, self.anchor_index(),
                             a_slot, m_slot, dx, dy)
            except Exception:
                pass
        self._refresh_mode_label()
        self._refresh_offset_warning()
        pcbnew.Refresh()

    def _on_swap(self, _evt):
        if len(self._footprints) != 2:
            return
        sel = self.anchor_choice.GetSelection()
        if sel == wx.NOT_FOUND:
            return
        self.anchor_choice.SetSelection(1 - sel)
        a = self.anchor_picker.value()
        m = self.move_picker.value()
        self.anchor_picker.set(m)
        self.move_picker.set(a)
        self._update()

    def _on_reset_offset(self, _evt):
        self.dx_ctrl.SetValue("0")
        self.dy_ctrl.SetValue("0")

    def _refresh_offset_warning(self):
        dx, dy = self.offset_mm()
        nonzero = dx != 0 or dy != 0
        label = "Offset (mm) - NON-ZERO" if nonzero else "Offset (mm)"
        self.off_static.SetLabel(label)
        color = wx.Colour(180, 30, 30) if nonzero else wx.NullColour
        self.off_static.SetForegroundColour(color)
        self.off_static.Refresh()

    def _refresh_mode_label(self):
        a = self.anchor_picker.value()
        m = self.move_picker.value()
        n = len(self._footprints)
        prefix = "Chain {} fp's | ".format(n) if n > 2 else ""
        if _is_corner(a) and _is_corner(m):
            txt = "{}Mode: Corner -> Corner  ({} -> {})".format(prefix, a, m)
            color = wx.Colour(40, 120, 40)
        elif _is_edge(a) and _is_edge(m):
            a_h = a in HORIZONTAL_EDGES
            m_h = m in HORIZONTAL_EDGES
            if a_h == m_h:
                txt = "{}Mode: Edge -> Edge  ({} -> {})".format(prefix, a, m)
                color = wx.Colour(40, 120, 40)
            else:
                txt = "Edges must share orientation (both T/B or both L/R)"
                color = wx.Colour(180, 30, 30)
        else:
            txt = "Pick two corners OR two edges (not mixed)"
            color = wx.Colour(180, 30, 30)
        self.mode_label.SetLabel(txt)
        self.mode_label.SetForegroundColour(color)
        self.Layout()

    def _on_ok(self, _evt):
        # board already in previewed state
        self.EndModal(wx.ID_OK)

    def _on_cancel(self, _evt):
        self._restore_positions()
        pcbnew.Refresh()
        self.EndModal(wx.ID_CANCEL)

    def _on_close(self, _evt):
        # window X = cancel
        self._restore_positions()
        pcbnew.Refresh()
        self.EndModal(wx.ID_CANCEL)

    def anchor_index(self):
        idx = self.anchor_choice.GetSelection()
        return idx if idx != wx.NOT_FOUND else 0

    def picks(self):
        return self.anchor_picker.value(), self.move_picker.value()

    def offset_mm(self):
        def parse(ctrl):
            try:
                return float(ctrl.GetValue().replace(",", "."))
            except ValueError:
                return 0.0
        return parse(self.dx_ctrl), parse(self.dy_ctrl)

    def offset_nm(self):
        dx_mm, dy_mm = self.offset_mm()
        return pcbnew.FromMM(dx_mm), pcbnew.FromMM(dy_mm)


class SnapCourtYardPlugin(pcbnew.ActionPlugin):
    "Interactive Snap CourtYard."

    def defaults(self):
        self.name = "Snap CourtYard"
        self.category = "Layout Helper"
        self.description = "Snap footprint courtyards corner-to-corner or edge-to-edge."
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "icon.png")

    def Run(self):
        board = pcbnew.GetBoard()
        if board is None:
            wx.MessageBox("No board open.", "Snap CourtYard", wx.ICON_ERROR)
            return

        fps = _selected_footprints_ordered(board)
        if len(fps) < 2:
            wx.MessageBox(
                "Select at least two unlocked footprints (got {}).".format(len(fps)),
                "Snap CourtYard", wx.ICON_INFORMATION)
            return

        # Shift+click toolbar = skip dialog, reuse last config
        try:
            shift_held = wx.GetMouseState().ShiftDown()
        except Exception:
            shift_held = False
        if shift_held and _apply_persisted(board, fps):
            return

        settings = _load_settings()
        dlg = _SnapDialog(None, fps, settings)
        try:
            result = dlg.ShowModal()
            if result != wx.ID_OK:
                return
            a_idx = dlg.anchor_index()
            a_slot, m_slot = dlg.picks()
            dx_mm, dy_mm = dlg.offset_mm()
        finally:
            dlg.Destroy()

        settings["dx_mm"] = dx_mm
        settings["dy_mm"] = dy_mm
        settings["anchor_slot"] = a_slot
        settings["move_slot"] = m_slot
        # anchor_index intentionally not persisted: selection composition
        # changes between runs; always derive default from selection order.
        settings.pop("anchor_index", None)
        _save_settings(settings)
        pcbnew.Refresh()


class SnapCourtYardRepeatPlugin(pcbnew.ActionPlugin):
    "Re-apply last Snap CourtYard config without dialog."

    def defaults(self):
        self.name = "Snap CourtYard (Repeat)"
        self.category = "Layout Helper"
        self.description = ("Re-apply the last Snap CourtYard configuration "
                            "to the current selection without showing a dialog.")
        self.show_toolbar_button = True
        self.icon_file_name = os.path.join(os.path.dirname(__file__), "icon.png")

    def Run(self):
        board = pcbnew.GetBoard()
        if board is None:
            wx.MessageBox("No board open.", "Snap CourtYard", wx.ICON_ERROR)
            return
        fps = _selected_footprints_ordered(board)
        if len(fps) < 2:
            wx.MessageBox(
                "Select at least two unlocked footprints.",
                "Snap CourtYard", wx.ICON_INFORMATION)
            return
        if not _apply_persisted(board, fps):
            wx.MessageBox(
                "No saved configuration. Run the main Snap CourtYard plugin first.",
                "Snap CourtYard", wx.ICON_INFORMATION)
