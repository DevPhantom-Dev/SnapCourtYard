"This file is executed when the package is imported (on PCB editor startup)"

from .snap_courtyard_action import (
    SnapCourtYardMarkAnchorPlugin,
    SnapCourtYardPlugin,
    SnapCourtYardRepeatPlugin,
)

SnapCourtYardPlugin().register()
SnapCourtYardRepeatPlugin().register()
SnapCourtYardMarkAnchorPlugin().register()
